--------------------------------------------
:mod:`pg` --- The Classic PyGreSQL Interface
--------------------------------------------

.. module:: pg

Contents
========

.. toctree::
    introduction
    module
    connection
    db_wrapper
    query
    large_objects
    notification
    db_types
    adaptation
