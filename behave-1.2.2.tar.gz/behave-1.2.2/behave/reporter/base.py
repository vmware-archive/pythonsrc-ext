class Reporter(object):
    def __init__(self, config):
        self.config = config

    def feature(self, feature):
        pass

    def end(self):
        pass
